import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";

import LoginScreen from "./Screens/Auth/LoginScreen";
import Navigation from "./Navigation/Navigation";
export default function App() {
  return <Navigation />;
}
