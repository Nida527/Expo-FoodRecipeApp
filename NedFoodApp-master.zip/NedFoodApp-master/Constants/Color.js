export default {
  primaryColor: "#FCA757",
  btnColor: "#F95856",
};
