import React from "react";
import { View, Text, Image, ScrollView } from "react-native";

const ScrollingScreen = () => {
  return (
    <ScrollView
      style={{
        flex: 1,
        backgroundColor: "white",
      }}
    >
      <View
      
        style={{ height: 300, with: "100%", backgroundColor: "red" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "green" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "purple" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "red" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "green" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "purple" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "red" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "green" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "purple" }}
      ></View>
      <View
        style={{ height: 300, with: "100%", backgroundColor: "red" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "green" }}
      ></View>

      <View
        style={{ height: 300, with: "100%", backgroundColor: "purple" }}
      ></View>

<View
      
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>
    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    
    
<View
      
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>
    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    
    
<View
      
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>
    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    
    
<View
      
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>
    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    
    
<View
      
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>
    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    
    
<View
      
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>
    <View
      style={{ height: 300, with: "100%", backgroundColor: "red" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "green" }}
    ></View>

    <View
      style={{ height: 300, with: "100%", backgroundColor: "purple" }}
    ></View>

    
    
      
    </ScrollView>
  );
};
export default ScrollingScreen;
